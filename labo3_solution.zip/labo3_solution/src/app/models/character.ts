export class Character{
    constructor(
        public name : string,
        public age : number,
        public occupation : string,
        public grade : string,
        public nbEpisodes : number
    ){}
}